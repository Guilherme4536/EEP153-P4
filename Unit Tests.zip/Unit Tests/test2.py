# test2.py
import pandas as pd
import numpy as np
from unittest.mock import Mock

def test_fct_loading():
    # Test Food Conversion Table structure
    dummy_fct = pd.DataFrame({
        'j': ['Coffee', 'Sugar'],
        'Calories': [0.5, 0.8],
        'Protein': [0.1, 0.2]
    }).set_index('j')
    
    assert not dummy_fct.empty
    assert 'Calories' in dummy_fct.columns
    assert isinstance(dummy_fct.index, pd.Index)

def test_rdi_loading():
    # Test Recommended Dietary Intakes structure
    dummy_rdi = pd.DataFrame({
        'n': ['Calories', 'Protein'],
        'Adult': [2000, 50],
        'Child': [1500, 25]
    }).set_index('n')
    
    assert not dummy_rdi.empty
    assert 'Adult' in dummy_rdi.columns
    assert dummy_rdi.index.name == 'n'

def test_regression_loading():
    # Mock regression object with pickle loading
    mock_regression = Mock()
    mock_regression.get_beta.return_value = np.array([0.4, 0.6])
    mock_regression.get_gamma.return_value = np.array([0.05, 0.1])
    
    assert mock_regression is not None
    assert len(mock_regression.get_beta()) == 2
    assert len(mock_regression.get_gamma()) == 2

def test_reference_prices():
    # Test price averaging logic
    dummy_p = pd.Series([10, 20, 30], index=['Coffee', 'Sugar', 'Salt'])
    pbar = dummy_p.mean()
    
    assert isinstance(pbar, float)
    assert 15 <= pbar <= 25  # Average should be 20

def test_budget_calculation():
    # Test median budget calculation
    dummy_xbar = pd.Series([100, 200, 300, 400, 500])
    xref = dummy_xbar.median()
    
    assert xref == 300
    assert isinstance(xref, float)

def test_quantity_calculation():
    # Test quantity = expenditure/price
    dummy_xhat = pd.DataFrame({
        'Coffee': [20, 40],
        'Sugar': [15, 30]
    })
    dummy_pbar = pd.Series({'Coffee': 5, 'Sugar': 3})
    
    qhat = dummy_xhat / dummy_pbar
    assert not qhat.empty
    assert round(qhat.loc[0, 'Coffee']) == 4
    assert round(qhat.loc[1, 'Sugar']) == 10

def test_price_modification():
    # Test my_price function
    def my_price(j, p9, p):
        p = p.copy()
        p.loc[j] = p9
        return p
        
    original_p = pd.Series({'Coffee': 5, 'Sugar': 3})
    modified_p = my_price('Coffee', 6, original_p)
    
    assert modified_p['Coffee'] == 6
    assert modified_p['Sugar'] == 3