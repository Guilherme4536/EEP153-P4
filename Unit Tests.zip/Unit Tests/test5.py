# test5.py
import pandas as pd
import numpy as np
import pytest
from unittest.mock import Mock

def test_nar_calculation():
    # Test basic NAR calculation with NaN handling
    achieved = pd.Series([150, 200, np.nan], index=['Calcium', 'Calcium', 'Iron'])
    required = pd.Series([100, 0, 50], index=['Calcium', 'Calcium', 'Iron'])
    nar = (achieved / required).replace([np.inf, -np.inf], np.nan).dropna()
    
    assert nar.iloc[0] == 1.5
    assert len(nar) == 1  # Only valid ratio remains

def test_price_multipliers():
    # Test complex price modifications
    base_prices = pd.Series({'Milk': 5.0, 'Teff': 3.0, 'Rice': 4.0})
    multipliers = {'Milk': 0.4, 'Teff': 0.4}
    
    modified = base_prices.copy()
    for item, mult in multipliers.items():
        if item in modified.index:
            modified[item] *= mult
            
    assert modified['Milk'] == 2.0
    assert modified['Teff'] == pytest.approx(1.2, rel=1e-9)  # Allow minor floating-point differences
    assert modified['Rice'] == 4.0  # Unmodified item

def test_fiscal_calculation():
    # Test fiscal cost calculation with scaling factors
    dummy_subsidies = pd.Series([100, 200])
    weeks = 52
    scaling = 1.5
    exchange_rate = 133.82
    
    total_subsidy = dummy_subsidies.sum() * weeks * scaling
    usd_cost = total_subsidy / exchange_rate
    
    assert pytest.approx(usd_cost, 0.01) == (300 * 52 * 1.5) / 133.82

def test_adequacy_plot():
    # Test histogram with reference lines
    dummy_data = pd.Series(np.random.normal(1, 0.2, 100))
    ax = dummy_data.hist(bins=40)
    
    # Add reference lines
    ax.axvline(1, color='red', ls='--')
    ax.axvline(1.2, color='blue')
    
    assert len(ax.lines) == 2
    assert ax.patches[0].get_height() > 0

def test_fct_alignment():
    # Test FCT-consumption alignment
    dummy_fct = pd.DataFrame({'Calcium': [100, 200]}, index=['Milk', 'Teff'])
    dummy_cons = pd.Series([2, 3], index=['Milk', 'Rice'])
    
    # Inner join should only keep 'Milk'
    aligned_fct, aligned_cons = dummy_fct.align(dummy_cons, axis=0, join='inner')
    
    assert len(aligned_fct) == 1
    assert aligned_cons.index[0] == 'Milk'

def test_cash_allocation():
    # Test budget multiplier with subsidy parameters
    total_funds = 600_000_000
    cash_share = 0.3
    k_c = 493_601_412 / 0.10  # From reference implementation
    
    cash_usd = total_funds * cash_share
    budget_mult = 1 + cash_usd / k_c
    
    assert pytest.approx(budget_mult, 0.01) == 1 + (180_000_000 / 4_936_014_120)

def test_subsidy_calculation():
    # Test price subsidy calculation
    q = pd.Series([2, 3], index=['Milk', 'Teff'])
    p_full = pd.Series([5.0, 3.0], index=['Milk', 'Teff'])
    p_sub = pd.Series([2.0, 1.2], index=['Milk', 'Teff'])
    
    subsidy = (q * (p_full - p_sub)).sum()
    assert subsidy == (2*(5-2) + 3*(3-1.2)) == 6 + 5.4 == 11.4