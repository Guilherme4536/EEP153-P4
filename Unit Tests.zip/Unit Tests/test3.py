# test3.py
import pandas as pd
import numpy as np
from unittest.mock import Mock

def test_demand_curves():
    # Mock demand function
    mock_r = Mock()
    mock_r.demands.return_value = np.array([5, 10, 15])
    
    scale = np.linspace(0.5, 2, 3)
    demands = [mock_r.demands(None, None) for _ in scale]
    
    assert len(demands) == 3
    assert isinstance(demands[0], np.ndarray)

def test_engel_curves():
    # Test log budget vs expenditure share
    dummy_data = pd.Series(np.log([1, 2, 3]))
    ax = dummy_data.plot()
    
    assert ax is not None
    assert len(ax.lines) > 0  # Check if plot has data

def test_fct_alignment():
    # Test FCT and consumption alignment
    dummy_fct = pd.DataFrame({'j': ['Milk', 'Bread'], 'Protein': [3, 4]})
    dummy_c = pd.DataFrame({'j': ['Milk', 'Bread'], 'Quantity': [2, 5]})
    
    # Mock alignment
    aligned_fct, aligned_c = dummy_fct, dummy_c  # Simplified alignment
    assert not aligned_fct.empty
    assert not aligned_c.empty
    assert aligned_fct.shape[0] == aligned_c.shape[0]

def test_nutrient_calculation():
    # Test matrix multiplication for nutrients
    dummy_fct = pd.DataFrame({
        'Protein': [3, 4],
        'Calories': [50, 60]
    }, index=['Milk', 'Bread'])
    
    dummy_c = pd.DataFrame({
        'Quantity': [2, 5]
    }, index=['Milk', 'Bread'])
    
    N = dummy_fct.T @ dummy_c
    assert not N.empty
    assert 'Protein' in N.index
    assert N.loc['Protein', 'Quantity'] == 26  # (3*2 + 4*5)

def test_nutrient_demand_function():
    # Test nutrient demand wrapper
    def mock_demands(x, p):
        return pd.Series([2, 5], index=['Milk', 'Bread'])
    
    mock_r = Mock()
    mock_r.demands.side_effect = mock_demands
    
    dummy_fct = pd.DataFrame({
        'Protein': [3, 4],
        'Calories': [50, 60]
    }, index=['Milk', 'Bread'])
    
    # Test function - corrected assertion
    N = dummy_fct.T @ mock_demands(None, None)
    assert N['Protein'] == 26
    assert N['Calories'] == 400  # Corrected from 340 to 400 (2*50 + 5*60)

def test_household_requirements():
    # Test RDI calculation - fixed arithmetic
    dummy_dbar = pd.Series([2.5, 1.2], index=['Adults', 'Children'])
    dummy_rdi = pd.DataFrame({
        'Protein': [50, 20],
        'Calories': [2000, 1500]
    }, index=['Adults', 'Children'])
    
    nh_rdi = dummy_rdi.T @ dummy_dbar
    assert nh_rdi['Protein'] == 149  # Corrected from 170 to 149 (50*2.5 + 20*1.2)
    assert nh_rdi['Calories'] == 6800